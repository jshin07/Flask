SELECT * FROM users;


